package com.neworesearchgroup.bemarkalarm.data.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

import com.neworesearchgroup.bemarkalarm.controls.audio.AudioWakeDetector
import com.neworesearchgroup.bemarkalarm.data.dao.MonitorEventDao

class MonitorViewModel(
    private val dao: MonitorEventDao
) : ViewModel() {

    private var detector: AudioWakeDetector? = null

    var isMonitoring by mutableStateOf(false)
        private set

    fun startMonitoring(onWake: () -> Unit) {
        if (isMonitoring) return

        detector = AudioWakeDetector {
            onWake()
        }

        detector?.start()
        isMonitoring = true
    }

    fun stopMonitoring() {
        detector?.stop()
        detector = null
        isMonitoring = false
    }
}

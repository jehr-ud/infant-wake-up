package com.neworesearchgroup.bemarkalarm.controls.audio

import android.annotation.SuppressLint
import android.Manifest
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.annotation.RequiresPermission

class AudioWakeDetector(
    private val onWakeDetected: () -> Unit
) {

    private val sampleRate = 16000
    private val bufferSize = AudioRecord.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    )

    private var recorder: AudioRecord? = null
    private var running = false
    private var loudCounter = 0

    @SuppressLint("MissingPermission")
    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    fun start() {
        if (running) return

        if (bufferSize <= 0) {
            return
        }

        recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        if (recorder?.state != AudioRecord.STATE_INITIALIZED) {
            recorder?.release()
            recorder = null
            return
        }

        recorder?.startRecording()
        running = true

        Thread {
            val buffer = ShortArray(bufferSize)

            while (running) {
                val read = recorder?.read(buffer, 0, buffer.size) ?: 0
                if (read <= 0) continue

                val rms = calculateRms(buffer, read)

                if (rms > 2000) loudCounter++ else loudCounter = 0

                if (loudCounter > 10) {
                    onWakeDetected()
                    loudCounter = 0
                }
            }
        }.start()
    }

    fun stop() {
        running = false
        recorder?.stop()
        recorder?.release()
        recorder = null
    }

    private fun calculateRms(buffer: ShortArray, read: Int): Double {
        var sum = 0.0
        for (i in 0 until read) {
            sum += buffer[i] * buffer[i]
        }
        return kotlin.math.sqrt(sum / read)
    }
}


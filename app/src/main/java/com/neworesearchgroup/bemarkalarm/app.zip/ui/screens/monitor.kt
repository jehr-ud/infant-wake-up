package com.neworesearchgroup.bemarkalarm.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.neworesearchgroup.bemarkalarm.controls.audio.AudioMonitorService
import com.neworesearchgroup.bemarkalarm.data.viewmodel.MonitorViewModel
import com.neworesearchgroup.bemarkalarm.ui.utils.AlarmPlayer






@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun MonitorScreen(
    viewModel: MonitorViewModel,
    onAlert: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as Activity

    val alarmPlayer = remember { AlarmPlayer(context) }


    val audioPermissionLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                startAudioService(context)
            }
        }

    val notificationPermissionLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            // No bloqueamos la app si no lo concede
        }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {

        Text(
            if (viewModel.isMonitoring) "Monitoring active"
            else "Monitoring stopped",
            fontSize = 22.sp
        )

        Spacer(Modifier.height(24.dp))

        Button(
            onClick = {

                /* ---- 1️⃣ PEDIR NOTIFICACIONES (Android 13+) ---- */
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        notificationPermissionLauncher.launch(
                            Manifest.permission.POST_NOTIFICATIONS
                        )
                    }
                }

                if (ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    startAudioService(context)
                } else {
                    audioPermissionLauncher.launch(
                        Manifest.permission.RECORD_AUDIO
                    )
                }
            }
        ) {
            Text("Start Monitoring")
        }

        val isListening by AudioMonitorService.isListening.collectAsState()

        Text(
            text = if (isListening) "🎤 Listening..." else "⛔ Not listening",
            fontSize = 18.sp
        )

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                context.stopService(
                    Intent(context, AudioMonitorService::class.java)
                )
            }
        ) {
            Text("Stop Monitoring")
        }
    }
}


private fun startAudioService(context: Context) {
    val intent = Intent(context, AudioMonitorService::class.java)
    ContextCompat.startForegroundService(context, intent)
}
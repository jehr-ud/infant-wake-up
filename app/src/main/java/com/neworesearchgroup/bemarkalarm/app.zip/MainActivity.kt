package com.neworesearchgroup.bemarkalarm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.room.Room
import com.google.firebase.auth.FirebaseAuth
import com.neworesearchgroup.bemarkalarm.controls.notification.NotificationUtils
import com.neworesearchgroup.bemarkalarm.data.database.BemarkDatabase
import com.neworesearchgroup.bemarkalarm.data.model.MonitorEvent
import com.neworesearchgroup.bemarkalarm.data.viewmodel.LoginViewModel
import com.neworesearchgroup.bemarkalarm.data.viewmodel.MonitorViewModel
import com.neworesearchgroup.bemarkalarm.data.viewmodel.RegisterViewModel
import com.neworesearchgroup.bemarkalarm.ui.screens.LoginScreen
import com.neworesearchgroup.bemarkalarm.ui.screens.MonitorScreen
import com.neworesearchgroup.bemarkalarm.ui.screens.RegisterScreen
import com.neworesearchgroup.bemarkalarm.ui.screens.ReportScreen
import com.neworesearchgroup.bemarkalarm.ui.theme.BemarkTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        NotificationUtils.createChannel(this)

        setContent {
            BemarkTheme {
                val navController = rememberNavController()
                val auth = FirebaseAuth.getInstance()

                // Decide pantalla inicial
                val startDestination = if (auth.currentUser != null) {
                    "monitor"
                } else {
                    "login"
                }

                NavHost(
                    navController = navController,
                    startDestination = startDestination
                ) {

                    composable("login") {
                        val viewModel: LoginViewModel = viewModel()

                        LoginScreen(
                            viewModel = viewModel,
                            onLoginSuccess = {
                                navController.navigate("monitor") {
                                    popUpTo("login") { inclusive = true }
                                }
                            },
                            onGoToRegister = {
                                println("GO TO REGISTER")
                                navController.navigate("register")
                            }
                        )
                    }

                    composable("monitor") {
                        val context = LocalContext.current
                        val database = remember {
                            Room.databaseBuilder(
                                context,
                                BemarkDatabase::class.java,
                                "bemark_db"
                            ).build()
                        }

                        val viewModel = remember {
                            MonitorViewModel(database.monitorEventDao())
                        }

                        MonitorScreen(
                            viewModel = viewModel,
                            onAlert = {
                                navController.navigate("report")
                            }
                        )
                    }

                    composable("report") {
                        val context = LocalContext.current
                        val database = remember {
                            Room.databaseBuilder(
                                context,
                                BemarkDatabase::class.java,
                                "bemark_db"
                            ).build()
                        }

                        val dao = database.monitorEventDao()

                        var events by remember { mutableStateOf<List<MonitorEvent>>(emptyList()) }

                        LaunchedEffect(Unit) {
                            events = dao.getAll()
                        }

                        ReportScreen(
                            events = events,
                            onContinue = {
                                navController.navigate("monitor") {
                                    popUpTo("report") { inclusive = true }
                                }
                            }
                        )
                    }

                    composable("register") {
                        val viewModel: RegisterViewModel = viewModel()

                        RegisterScreen(
                            viewModel = viewModel,
                            onRegisterSuccess = {
                                navController.navigate("monitor") {
                                    popUpTo("register") { inclusive = true }
                                }
                            },
                            onGoToLogin = {
                                navController.navigate("login")
                            }
                        )
                    }
                }
            }
        }
    }
}

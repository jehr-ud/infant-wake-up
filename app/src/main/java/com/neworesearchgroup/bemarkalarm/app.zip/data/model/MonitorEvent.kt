package com.neworesearchgroup.bemarkalarm.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "monitor_events")
data class MonitorEvent(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val type: String, // SOUND, FACE_COVERED, ABSENCE
    val description: String
)
